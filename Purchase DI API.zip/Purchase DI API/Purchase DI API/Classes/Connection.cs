﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Purchase_DI_API.Classes
{
    class Connection
    {
        SAPbobsCOM.Company oCompany = new SAPbobsCOM.Company();

        int ret, ErrorNo;
        string ErrorMsg;

        //public void Connecetion(string UID,String PWD) 
        //{
        //    try
        //    {
        //        oCompany.CompanyDB = "EUR";
        //        oCompany.Server = "BIZ-DI001";
        //        oCompany.LicenseServer = "BIZ-DI001:30000";

        //        oCompany.SLDServer = "BIZ-DI001:40000";     //  
        //        oCompany.DbUserName = "sa"; // 
        //        oCompany.DbPassword = "ok"; //
        //        oCompany.UserName = UID; //
        //        oCompany.Password = PWD; // 
        //        oCompany.DbServerType = SAPbobsCOM.BoDataServerTypes.dst_MSSQL;               
        //        oCompany.UseTrusted = false;
        //        MessageBox.Show("Successful", "Complete", MessageBoxButtons.OK, MessageBoxIcon.None);

        //        //res=oCompany.Connect();
        //        //errMsg = oCompany.GetLastErrorDescription();
        //        //ErrNo = oCompany.GetLastErrorCode();

        //        //if (ErrNo != 0)
        //        //{
        //        //    value1 = errMsg;
        //        //    //return errMsg;
        //        //}
        //        //else
        //        //{
        //        //    value1 = "Succes Connection To Sap B1 Hana";
        //        //    //return value1;
        //        //}
        //    }
        //    catch (Exception eX)
        //    {
        //        MessageBox.Show(eX.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
        //    }

            public void GetConnection(string companydb, string server, string licenseserver, string sldserver, string dbusername, string dbpassword, string username, string password, SAPbobsCOM.BoDataServerTypes dbservertype , bool usetrusted) 
            {
            try
            {
                oCompany.CompanyDB = companydb;
                oCompany.Server = server;
                oCompany.LicenseServer = licenseserver;
                oCompany.SLDServer = sldserver;
                oCompany.DbUserName = dbusername;
                oCompany.DbPassword = dbpassword;
                oCompany.UserName = username;
                oCompany.Password = password;
                oCompany.DbServerType = dbservertype;
                oCompany.UseTrusted = usetrusted;

                ret = oCompany.Connect();
                ErrorMsg = oCompany.GetLastErrorDescription();
                ErrorNo = oCompany.GetLastErrorCode();

                if (ErrorNo != 0)
                {
                    MessageBox.Show(ErrorMsg);
                }
                else
                {
                    MessageBox.Show("Connection have been connected");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
    }
}
