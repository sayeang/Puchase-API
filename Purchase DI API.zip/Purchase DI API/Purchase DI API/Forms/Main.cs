﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Purchase_DI_API
{
    public partial class frmMain : Form
    {
        Classes.Connection CNN = new Classes.Connection();
        int maxornot;
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnExitFull_Click(object sender, EventArgs e)
        {                  

            if (WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
                btnExitFull.BackgroundImage = Purchase_DI_API.Properties.Resources.full_screen;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
                btnExitFull.BackgroundImage = Purchase_DI_API.Properties.Resources.Exit_full_screen;                   
            }
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //Forms.frmLogin frmLog = new Forms.frmLogin();
            ////CNN.Connecetion(frmLog.txtUserID.ToString(),frmLog.txtPassword.ToString());
            //CNN.GetConnection("EUR", "BIZ-DI001", "BIZ-DI001:30000", "BIZ-DI001:40000", "sa", "ok",frmLog.txtUserID.ToString(),frmLog.txtPassword.ToString(),SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017, true);
            LoadForm();
        }

        private void LoadForm()
        {
            Forms.frmLogin frm = new Forms.frmLogin() { TopLevel = false, TopMost = true };
            frm.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            this.pnMain.Controls.Add(frm);
            frm.Show();
        }

        private void Center(Control ctrCenter)
        {
            ctrCenter.Left = (ctrCenter.Parent.Width - ctrCenter.Width) / 2;
            ctrCenter.Top = (ctrCenter.Parent.Height - ctrCenter.Height) / 2;
        }
    }
}
