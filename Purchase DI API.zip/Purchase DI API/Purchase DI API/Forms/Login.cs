﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Purchase_DI_API.Forms
{
    public partial class frmLogin : Form
    {
        Classes.Connection CNN = new Classes.Connection();
        public frmLogin()
        {
            InitializeComponent();
        }

        private Point MouseDownLocation;

        private void pnControl_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                MouseDownLocation = e.Location;
            }
        }

        private void pnControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                //pnControl.Left = e.X + pnControl.Left - MouseDownLocation.X;
                //pnControl.Top = e.Y + pnControl.Top - MouseDownLocation.Y;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            string UserName = txtUserID.Text;
            string Password = txtPassword.Text;

            CNN.GetConnection("EUR", "BIZ-DI001", "BIZ-DI001:40000", "BIZ-DI001:40000", "sa", "ok", UserName, Password, SAPbobsCOM.BoDataServerTypes.dst_MSSQL2017, true);            
        }
    }
}
